# Load Images in Python

# Extract Landmarks with BlazePose(Mediapipe)


```python
pip install mediapipe
```

    Defaulting to user installation because normal site-packages is not writeable
    Requirement already satisfied: mediapipe in c:\users\user\appdata\roaming\python\python311\site-packages (0.10.21)
    Requirement already satisfied: absl-py in c:\users\user\appdata\roaming\python\python311\site-packages (from mediapipe) (2.3.1)
    Requirement already satisfied: attrs>=19.1.0 in c:\programdata\anaconda3\lib\site-packages (from mediapipe) (22.1.0)
    Requirement already satisfied: flatbuffers>=2.0 in c:\users\user\appdata\roaming\python\python311\site-packages (from mediapipe) (25.2.10)
    Requirement already satisfied: jax in c:\users\user\appdata\roaming\python\python311\site-packages (from mediapipe) (0.7.0)
    Requirement already satisfied: jaxlib in c:\users\user\appdata\roaming\python\python311\site-packages (from mediapipe) (0.7.0)
    Requirement already satisfied: matplotlib in c:\programdata\anaconda3\lib\site-packages (from mediapipe) (3.7.1)
    Requirement already satisfied: numpy<2 in c:\users\user\appdata\roaming\python\python311\site-packages (from mediapipe) (1.26.4)
    Requirement already satisfied: opencv-contrib-python in c:\users\user\appdata\roaming\python\python311\site-packages (from mediapipe) (4.11.0.86)
    Requirement already satisfied: protobuf<5,>=4.25.3 in c:\users\user\appdata\roaming\python\python311\site-packages (from mediapipe) (4.25.8)
    Requirement already satisfied: sounddevice>=0.4.4 in c:\users\user\appdata\roaming\python\python311\site-packages (from mediapipe) (0.5.2)
    Requirement already satisfied: sentencepiece in c:\users\user\appdata\roaming\python\python311\site-packages (from mediapipe) (0.2.1)
    Requirement already satisfied: CFFI>=1.0 in c:\programdata\anaconda3\lib\site-packages (from sounddevice>=0.4.4->mediapipe) (1.15.1)
    Requirement already satisfied: ml_dtypes>=0.5.0 in c:\users\user\appdata\roaming\python\python311\site-packages (from jax->mediapipe) (0.5.3)
    Requirement already satisfied: opt_einsum in c:\users\user\appdata\roaming\python\python311\site-packages (from jax->mediapipe) (3.4.0)
    Requirement already satisfied: scipy>=1.12 in c:\users\user\appdata\roaming\python\python311\site-packages (from jax->mediapipe) (1.16.1)
    Requirement already satisfied: contourpy>=1.0.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib->mediapipe) (1.0.5)
    Requirement already satisfied: cycler>=0.10 in c:\programdata\anaconda3\lib\site-packages (from matplotlib->mediapipe) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib->mediapipe) (4.25.0)
    Requirement already satisfied: kiwisolver>=1.0.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib->mediapipe) (1.4.4)
    Requirement already satisfied: packaging>=20.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib->mediapipe) (23.0)
    Requirement already satisfied: pillow>=6.2.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib->mediapipe) (9.4.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib->mediapipe) (3.0.9)
    Requirement already satisfied: python-dateutil>=2.7 in c:\programdata\anaconda3\lib\site-packages (from matplotlib->mediapipe) (2.8.2)
    Requirement already satisfied: pycparser in c:\programdata\anaconda3\lib\site-packages (from CFFI>=1.0->sounddevice>=0.4.4->mediapipe) (2.21)
    Requirement already satisfied: six>=1.5 in c:\programdata\anaconda3\lib\site-packages (from python-dateutil>=2.7->matplotlib->mediapipe) (1.16.0)
    Note: you may need to restart the kernel to use updated packages.
    


```python
import cv2
import os

# Path to dataset folder (change this to your dataset location)
data_dir = r"C:\Users\user\Downloads\archive (7)\Body_pose_classes"

images = []
labels = []

# Loop through each sub-folder (stand, duck, jump, etc.)
for label in os.listdir(data_dir):
    folder_path = os.path.join(data_dir, label)
    if not os.path.isdir(folder_path):
        continue
    
    for file in os.listdir(folder_path):
        img_path = os.path.join(folder_path, file)
        img = cv2.imread(img_path)
        if img is not None:
            images.append(img)
            labels.append(label)

print("Total images loaded:", len(images))
print("Unique labels:", set(labels))

import mediapipe as mp

mp_pose = mp.solutions.pose
pose = mp_pose.Pose()
landmark_list = []
labels_list = []

for idx, img in enumerate(images):
    rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    result = pose.process(rgb_img)
    if result.pose_landmarks:
        landmarks = []
        for lm in result.pose_landmarks.landmark:
            landmarks.append([lm.x, lm.y])
        landmark_list.append(landmarks)
        labels_list.append(labels[idx])

```

    Total images loaded: 3500
    Unique labels: {'power', 'kick', 'jump', 'duck', 'throw', 'punch', 'stand'}
    


    ---------------------------------------------------------------------------

    ImportError                               Traceback (most recent call last)

    Cell In[7], line 26
         23 print("Total images loaded:", len(images))
         24 print("Unique labels:", set(labels))
    ---> 26 import mediapipe as mp
         28 mp_pose = mp.solutions.pose
         29 pose = mp_pose.Pose()
    

    File ~\AppData\Roaming\Python\Python311\site-packages\mediapipe\__init__.py:15
          1 # Copyright 2019 - 2022 The MediaPipe Authors.
          2 #
          3 # Licensed under the Apache License, Version 2.0 (the "License");
       (...)
         12 # See the License for the specific language governing permissions and
         13 # limitations under the License.
    ---> 15 from mediapipe.python import *
         16 import mediapipe.python.solutions as solutions 
         17 import mediapipe.tasks.python as tasks
    

    File ~\AppData\Roaming\Python\Python311\site-packages\mediapipe\python\__init__.py:17
          1 # Copyright 2020-2021 The MediaPipe Authors.
          2 #
          3 # Licensed under the Apache License, Version 2.0 (the "License");
       (...)
         12 # See the License for the specific language governing permissions and
         13 # limitations under the License.
         15 """MediaPipe Python API."""
    ---> 17 from mediapipe.python._framework_bindings import model_ckpt_util
         18 from mediapipe.python._framework_bindings import resource_util
         19 from mediapipe.python._framework_bindings.calculator_graph import CalculatorGraph
    

    ImportError: DLL load failed while importing _framework_bindings: A dynamic link library (DLL) initialization routine failed.


# Convert to a CSV File


```python
pip install pandas

```


```python
import os
import cv2
import mediapipe as mp
import numpy as np
import pandas as pd

# Path to dataset
data_dir =  r"C:\Users\user\Downloads\archive (7)\Body_pose_classes" 

mp_pose = mp.solutions.pose
pose = mp_pose.Pose()

landmark_list = []
labels_list = []

# Loop through each sub-folder (stand, duck, jump, etc.)
for label in os.listdir(data_dir):
    folder_path = os.path.join(data_dir, label)
    if not os.path.isdir(folder_path):
        continue  # skip non-folder files

    # Loop through each image in the sub-folder
    for file in os.listdir(folder_path):
        img_path = os.path.join(folder_path, file)
        img = cv2.imread(img_path)
        if img is None:
            continue  # skip unreadable files

        # Convert image to RGB
        rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        result = pose.process(rgb_img)

        # Extract landmarks if found
        if result.pose_landmarks:
            landmarks = []
            for lm in result.pose_landmarks.landmark:
                landmarks.append([lm.x, lm.y])  # (x, y)
            landmark_list.append(np.array(landmarks).flatten())  # flatten 33x2 → 66
            labels_list.append(label)  # save label

```


```python
# Convert to DataFrame
df = pd.DataFrame(landmark_list)
df['label'] = labels_list

# Save CSV
df.to_csv("pose_landmarks.csv", index=False)

print("CSV saved with shape:", df.shape)
print("Labels found:", set(labels_list))

```

# Upload into ML Model 


```python
!pip install seaborn

```

    Defaulting to user installation because normal site-packages is not writeable
    Requirement already satisfied: seaborn in c:\programdata\anaconda3\lib\site-packages (0.12.2)
    Requirement already satisfied: numpy!=1.24.0,>=1.17 in c:\users\user\appdata\roaming\python\python311\site-packages (from seaborn) (1.26.4)
    Requirement already satisfied: pandas>=0.25 in c:\programdata\anaconda3\lib\site-packages (from seaborn) (1.5.3)
    Requirement already satisfied: matplotlib!=3.6.1,>=3.1 in c:\programdata\anaconda3\lib\site-packages (from seaborn) (3.7.1)
    Requirement already satisfied: contourpy>=1.0.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (1.0.5)
    Requirement already satisfied: cycler>=0.10 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (4.25.0)
    Requirement already satisfied: kiwisolver>=1.0.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (1.4.4)
    Requirement already satisfied: packaging>=20.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (23.0)
    Requirement already satisfied: pillow>=6.2.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (9.4.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (3.0.9)
    Requirement already satisfied: python-dateutil>=2.7 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in c:\programdata\anaconda3\lib\site-packages (from pandas>=0.25->seaborn) (2022.7)
    Requirement already satisfied: six>=1.5 in c:\programdata\anaconda3\lib\site-packages (from python-dateutil>=2.7->matplotlib!=3.6.1,>=3.1->seaborn) (1.16.0)
    


```python
import pandas as pd
import numpy as np 
import matplotlib.pyplot as plot 
%matplotlib inline 
import seaborn as sns

file_name = "pose_landmarks.csv"
df = read_csv = pd.read_csv(file_name)

print(df.head())
```

              0         1         2         3         4         5         6  \
    0  0.411859  0.775060  0.411287  0.769368  0.412456  0.767781  0.413653   
    1  0.425403  0.728552  0.423658  0.728241  0.423558  0.727736  0.423504   
    2  0.452051  0.714074  0.446192  0.712354  0.445042  0.710510  0.443958   
    3  0.458026  0.742433  0.458455  0.741967  0.459071  0.742001  0.459692   
    4  0.320778  0.726885  0.322206  0.723615  0.323765  0.723668  0.325343   
    
              7         8         9  ...        57        58        59        60  \
    0  0.766230  0.407225  0.773239  ...  0.892999  0.481729  0.831789  0.390969   
    1  0.727225  0.422925  0.729667  ...  0.738679  0.412580  0.767905  0.481260   
    2  0.708602  0.448630  0.718384  ...  0.831791  0.414099  0.777403  0.438319   
    3  0.742050  0.456587  0.741725  ...  0.727314  0.471175  0.719489  0.491256   
    4  0.723696  0.316870  0.722589  ...  0.786910  0.324701  0.778269  0.285315   
    
             61        62        63        64        65  label  
    0  0.900133  0.493309  0.832282  0.369674  0.911012   duck  
    1  0.740261  0.401777  0.770842  0.489937  0.745699   duck  
    2  0.835485  0.409950  0.780294  0.434683  0.856243   duck  
    3  0.728851  0.465515  0.729765  0.493204  0.734096   duck  
    4  0.794041  0.319398  0.800727  0.271233  0.811624   duck  
    
    [5 rows x 67 columns]
    


```python
print(f"Number of columns", df.shape[1])
print("\n Column names")
print(df.columns.tolist())

print("\n Basic Statistics")
print(df.describe())

print("\n Missing Value")
print(df.isnull().sum())
```

    Number of columns 67
    
     Column names
    ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', 'label']
    
     Basic Statistics
                    0           1           2           3           4           5  \
    count  767.000000  767.000000  767.000000  767.000000  767.000000  767.000000   
    mean     0.433214    0.573723    0.434170    0.571751    0.434279    0.571196   
    std      0.151718    0.242068    0.155170    0.245503    0.155542    0.244979   
    min      0.093917    0.079518    0.087071    0.079095    0.085150    0.079036   
    25%      0.309352    0.333338    0.306316    0.328632    0.305817    0.328573   
    50%      0.455661    0.610397    0.453652    0.608741    0.450340    0.609682   
    75%      0.555677    0.817528    0.561503    0.815483    0.561477    0.815192   
    max      0.728978    0.938227    0.727111    0.942233    0.725749    0.941342   
    
                    6           7           8           9  ...          56  \
    count  767.000000  767.000000  767.000000  767.000000  ...  767.000000   
    mean     0.434417    0.570682    0.433715    0.573156  ...    0.412645   
    std      0.155924    0.244484    0.154178    0.246964  ...    0.139138   
    min      0.083284    0.078928    0.092720    0.079427  ...    0.102705   
    25%      0.305518    0.328181    0.308000    0.326548  ...    0.295385   
    50%      0.449792    0.610462    0.456436    0.605505  ...    0.399300   
    75%      0.563032    0.814269    0.558807    0.819340  ...    0.522778   
    max      0.724361    0.940627    0.731849    0.947394  ...    0.815249   
    
                   57          58          59          60          61          62  \
    count  767.000000  767.000000  767.000000  767.000000  767.000000  767.000000   
    mean     0.642020    0.428064    0.607140    0.411443    0.643967    0.432752   
    std      0.182705    0.121862    0.163949    0.145234    0.186113    0.127224   
    min      0.131741    0.100366    0.128522    0.081918    0.132683    0.070668   
    25%      0.487407    0.341150    0.504549    0.286044    0.485240    0.338876   
    50%      0.712486    0.428640    0.609029    0.402204    0.716987    0.438663   
    75%      0.789938    0.512976    0.749715    0.521576    0.792717    0.522810   
    max      0.960000    0.803044    0.979941    0.817029    0.963517    0.811542   
    
                   63          64          65  
    count  767.000000  767.000000  767.000000  
    mean     0.609426    0.411730    0.651197  
    std      0.171264    0.151206    0.198922  
    min      0.098404    0.066186    0.120895  
    25%      0.498390    0.283637    0.483998  
    50%      0.607998    0.409253    0.724434  
    75%      0.762724    0.529432    0.815580  
    max      0.975545    0.830111    0.965590  
    
    [8 rows x 66 columns]
    
     Missing Value
    0        0
    1        0
    2        0
    3        0
    4        0
            ..
    62       0
    63       0
    64       0
    65       0
    label    0
    Length: 67, dtype: int64
    


```python
sns.histplot(x="label",data=df)
plot.show()
```


    
![png](output_12_0.png)
    



```python
sns.boxplot(x="label",y=df['0'], data = df)
plot.show()
```


    
![png](output_13_0.png)
    



```python
sns.scatterplot(x=df['30'], y=df['31'], hue=df['label'], palette='Set2')
plot.legend(bbox_to_anchor = (1,1) , loc = 2)
plot.show()
```


    
![png](output_14_0.png)
    


# Full Body Pose Recognition ML Pipeline


```python
import sys
print(sys.executable)
# For Jupyter notebooks
import sys
!{sys.executable} -m pip install imbalanced-learn
```

    C:\ProgramData\anaconda3\python.exe
    Defaulting to user installation because normal site-packages is not writeable
    Requirement already satisfied: imbalanced-learn in c:\programdata\anaconda3\lib\site-packages (0.10.1)
    Requirement already satisfied: numpy>=1.17.3 in c:\users\user\appdata\roaming\python\python311\site-packages (from imbalanced-learn) (1.26.4)
    Requirement already satisfied: scipy>=1.3.2 in c:\users\user\appdata\roaming\python\python311\site-packages (from imbalanced-learn) (1.16.1)
    Requirement already satisfied: scikit-learn>=1.0.2 in c:\programdata\anaconda3\lib\site-packages (from imbalanced-learn) (1.3.0)
    Requirement already satisfied: joblib>=1.1.1 in c:\programdata\anaconda3\lib\site-packages (from imbalanced-learn) (1.2.0)
    Requirement already satisfied: threadpoolctl>=2.0.0 in c:\programdata\anaconda3\lib\site-packages (from imbalanced-learn) (2.2.0)
    


```python
!pip install --upgrade scikit-learn imbalanced-learn
```


```python
import sklearn
import imblearn
print("scikit-learn:", sklearn.__version__)
print("imbalanced-learn:", imblearn.__version__)

```


```python
from imblearn.over_sampling import SMOTE
from collections import Counter

# Check original class distribution
print("Original class distribution:", Counter(y_train))

# Apply SMOTE to training data
smote = SMOTE(random_state=42)
X_train_res, y_train_res = smote.fit_resample(X_train, y_train)

# Check new class distribution
print("Resampled class distribution:", Counter(y_train_res))

# Train your model on the resampled data
from sklearn.ensemble import RandomForestClassifier

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train_res, y_train_res)

# Evaluate
y_val_pred = model.predict(X_val)
y_test_pred = model.predict(X_test)

from sklearn.metrics import classification_report
print("Validation Report:\n", classification_report(y_val, y_val_pred))
print("Test Report:\n", classification_report(y_test, y_test_pred))
```


```python
# Import libraries
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Load the processed data 
file_name = "pose_landmarks.csv"
df = pd.read_csv(file_name)

print("Dataset loaded successfully!")
print("Shape:", df.shape)
print("Unique labels:", df['label'].unique())

#Handle missing values (numeric only) 
landmark_cols = df.drop('label', axis=1).columns
df[landmark_cols] = df[landmark_cols].fillna(df[landmark_cols].mean())

# Outlier Handling 
def remove_outliers_iqr(df, features):
    clean_df = df.copy()
    for col in features:
        Q1 = clean_df[col].quantile(0.25)
        Q3 = clean_df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        clean_df = clean_df[(clean_df[col] >= lower_bound) & (clean_df[col] <= upper_bound)]
    return clean_df

df = remove_outliers_iqr(df, landmark_cols)

print("After handling outliers, shape:", df.shape)

# Separate features and target 
X = df.drop('label', axis=1)
y = df['label']

#Train / Validation / Test Split
X_train, X_temp, y_train, y_temp = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)
X_val, X_test, y_val, y_test = train_test_split(
    X_temp, y_temp, test_size=0.5, random_state=42, stratify=y_temp
)

print("\nData Split:")
print(f"Training set: {X_train.shape[0]} samples")
print(f"Validation set: {X_val.shape[0]} samples")
print(f"Test set: {X_test.shape[0]} samples")

# Define and train the model 
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

#Evaluate on validation set 
val_pred = model.predict(X_val)
val_acc = accuracy_score(y_val, val_pred)
print(f"\nValidation Accuracy: {val_acc:.2f}")

#Evaluate on test set
y_pred = model.predict(X_test)
test_acc = accuracy_score(y_test, y_pred)
print(f"Test Accuracy: {test_acc:.2f}")

#Classification Report 
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

#Confusion Matrix Visualization 
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(6,5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=model.classes_, yticklabels=model.classes_)
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix - Body Pose Recognition")
plt.show()

#Feature Importance (Top 10)-
importances = model.feature_importances_
indices = np.argsort(importances)[-10:]

plt.figure(figsize=(8,4))
plt.barh(range(len(indices)), importances[indices])
plt.yticks(range(len(indices)), [f"Feature {i}" for i in indices])
plt.xlabel("Feature Importance")
plt.title("Top 10 Important Pose Features")
plt.show()
```


```python

```
